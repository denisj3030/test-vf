#!/usr/bin/env bash

echoerr() { printf "${RED}Failed${NC}\nError: %s\n" "$*" >&2; }
echowarn() { printf "${YELLOW}Warning: %s${NC}\n" "$*" >&2; }

LOGFILE="/tmp/robin-install.log"
NAMESPACE="robinio"
CLOUD_CRED_SECRET="cloud-cred-secret"
IS_CLOUD_CRED_SECRET=false
IS_ETC_HOSTS=false
IS_UPDATE_COREDNS=false
LB_NEEDED=true
STORAGE_DISKS=""
IMAGE_REGISTRY_PATH=""
IMAGE_PULL_SECRET=""
CUR_VERSION=5.3.4-592
IMAGE_REPO=robinsys
function validate_k8s_cluster() {
    get_client_os
    # Check kubectl
    OIFS=$IFS
    IFS=$'\n'
    get_kube_command
    $KUBE_COMMAND get nodes > /dev/null
    if [[ $? != 0 ]]; then
        echoerr "$KUBE_COMMAND failed to run."
        exit 1
    fi

    out=($($KUBE_COMMAND get nodes -o custom-columns=Name:.metadata.name,OSImage:.status.nodeInfo.osImage,KubeVersion:.status.nodeInfo.kubeProxyVersion,CPU:.status.capacity.cpu,Memory:.status.capacity.memory,providerID:.spec.providerID --no-headers | sed -e "s/  /,/g"| tr -s ","))

    if [[ $? != 0 ]]; then
        echoerr "$KUBE_COMMAND failed to run."
        exit 1
    fi

    # Check number of  nodes
    if [[ ${#out[@]} -lt 3 ]]; then
        echowarn "Robin recommends having 3 or more nodes in kubernetes for high availability"
    fi

    first=true
    k8s_provider=""
    host_type="physical"
    for host in ${out[@]}; do
        IFS=$','
        host="$(echo -e "${host}" | tr -d '[:space:]')"
        hostDetails=(${host})
        hostName=${hostDetails[0]}
        osImage=${hostDetails[1]}
        kubeVersion=${hostDetails[2]}
        cpu=${hostDetails[3]}
        memory=${hostDetails[4]}
        providerID=${hostDetails[5]}
        if [[ "$first" == true ]];  then
            if [[ $providerID =~ aws ]]; then
                host_type="ec2"
            elif [[ $providerID =~ gce ]]; then
                host_type="gcp"
            elif [[ $providerID =~ azure ]]; then
                host_type="azure"
            elif [[ $providerID =~ ibm ]]; then
                host_type="ibm"
            elif [[ $providerID =~ vsphere ]]; then
                host_type="physical"
            fi
            checkOpenShift4=$($KUBE_COMMAND get nodes $hostName -o "jsonpath={.metadata.labels.node\.openshift\.io/os_id}")
            #checkOpenShift3=$($KUBE_COMMAND get nodes $hostName -o "jsonpath={.metadata.annotations.node\.openshift\.io/md5sum}")
            #if [[ $checkOpenShift3 != "" ]] || [[ $checkOpenShift4 != "" ]]; then
            if [[ $checkOpenShift4 != "" ]]; then
                k8s_provider="openshift"
            else
                if [[ $host_type == "gcp" ]] || [[ $host_type == "physical" ]]; then
                    checkGKE=$($KUBE_COMMAND get nodes $hostName -o "jsonpath={.metadata.labels.cloud\.google\.com/gke-os-distribution}")
                    if [[ $checkGKE != "" ]]; then
                        if [[ $checkGKE == "cos" ]]; then
                            echoerr "Robin is not supported on Container optimized OS"
                            exit 1
                        fi
                        k8s_provider="gke"
                    else
                        checkRKE=$($KUBE_COMMAND get nodes $hostName -o "jsonpath={.metadata.annotations.rke\.cattle\.io/internal-ip}")
                        if [[ $checkRKE != "" ]]; then
                            k8s_provider="rke"
                        else
                            k8s_provider="upstream"
: <<'END'
                            while true; do
                                echo "\nType yes to if deployed Kubernetes is upstream kubernetes: "
                                read var
                                if [[ ! -z $var ]] && ([[ $var == 'yes' ]] || [[ $var == 'YES' ]]) ; then
                                    break
                                fi
                                if [[ ! -z $var ]] && ([[ $var == 'no' ]] || [[ $var == 'NO' ]]); then
                                    echoerr "Not able to discover type of Kubernetes. Please create robin.yaml with appropriate inputs and re-run this script with \"-f\" option"
                                    exit 1
                                fi
                            done
END
                        fi
                    fi
                elif [[ $host_type == "ec2" ]]; then
                    checkEKS=$($KUBE_COMMAND get nodes $hostName -o "jsonpath={.metadata.labels.alpha\.eksctl\.io/cluster-name}")
                    if [[ $checkEKS != "" ]]; then
                        k8s_provider="eks"
                    fi
                elif [[ $host_type == "ibm" ]]; then
                    checkIKS=$($KUBE_COMMAND get nodes $hostName -o "jsonpath={.metadata.labels.ibm-cloud\.kubernetes\.io/os}")
                    if [[ $checkIKS != "" ]]; then
                        k8s_provider="iks"
                    fi
                elif [[ $host_type == "azure" ]]; then
                    checkAKS=$($KUBE_COMMAND get nodes $hostName -o "jsonpath={.metadata.labels.kubernetes\.azure\.com/cluster}")
                    if [[ $checkAKS != "" ]]; then
                        k8s_provider="aks"
                    fi
                else
                    echoerr "Robin installation via get.robin.io is not supported on this kuberenetes flavor. Please contact robin at slack at https://robinio.slack.com or email at support@robin.io to get installable for this kubernetes flavor"
                    exit 1
                fi
            fi
        fi

        # Check kubernetes version
        # if ! [[ $kubeVersion =~ v1.1[1-3] ]]; then
        #     echoerr "Kubernetes version $kubeVersion is not supported for robin installation"
        #     exit 1
        # fi
        # Check min CPU
        if [[ $cpu -lt 2 ]]; then
            echoerr "Kubernetes nodes should have more than 2 CPUs but node has $cpu"
            exit 1
        fi
        #Assume unit is Ki which is always the case
        # Check min memory
        mem=${memory/%Ki/}
        if [[ $mem -lt 4000000 ]]; then
            echoerr "Kubernetes nodes should have more than 4 GB memory"
            exit 1
        fi
    done
    IFS=$OIFS

    if [[ ! -z $SKIP_LB ]]; then
        LB_NEEDED=false
    elif [[ $host_type == "physical" ]]; then
        LB_NEEDED=false
    fi
    echo "Host type=$host_type k8s_provider=$k8s_provider" >> $LOGFILE
}

function validate_perms() {
    if [[ $k8s_provider == 'gke' ]] && [[ $host_type == 'gcp' ]]; then
        which gcloud > /dev/null
        if [[ $? != 0 ]]; then
            return
        fi
        gout=$(gcloud container clusters describe $CLUSTER_NAME --zone $ZONE_NAME)
        echo $gout | grep "https://www.googleapis.com/auth/cloud-platform" > /dev/null 2>&1
        if [[ $? != 0 ]]; then
            echo $gout | grep 'https://www.googleapis.com/auth/compute' > /dev/null 2>&1
            if [[ $? != 0 ]]; then
                echoerr "Robin needs 'Compute Engine: Read Write' and 'Storage: Full' API  access. Alternatively, You can also give 'Full access to cloud APIs'. You can set it while creating GKE cluster by navigating to Create cluster -> nodepool: More options -> Security:Access scopes"
                exit 1
            fi
            echo $gout | egrep 'https://www.googleapis.com/auth/devstorage.full_control|https://www.googleapis.com/auth/devstorage.read_write' > /dev/null 2>&1
            if [[ $? != 0 ]]; then
                echoerr "Robin needs 'Compute Engine: Read Write' and 'Storage: Full' API  access. Alternatively, You can also give 'Full access to cloud APIs'. You can set it while creating GKE cluster by navigating to Create cluster -> nodepool: More options -> Security:Access scopes"
                exit 1
            fi
        fi
    fi
}

function validate_cr_yaml() {
    if [[ ! -z $CR_FILE ]]; then
        cr_file=$CR_FILE
        return
    fi
    cr_file="robin.yaml"
    cp -f ${cr_file} ${cr_file}.tmp
    if [[ $host_type == "ec2" ]]; then
        IS_CLOUD_CRED_SECRET=true
    elif [[ $host_type == "azure" ]]; then
        IS_CLOUD_CRED_SECRET=true
    elif [[ $k8s_provider == "gke" ]]; then
        if [[ $host_type == "physical" ]]; then
            #Anthos
            IS_ETC_HOSTS=true
            #STORAGE_DISKS="count=1,type=independent_persistent,size=40"
        else
            #GKE
            #STORAGE_DISKS="count=1,type=pd-ssd,size=200"
            :;
        fi
    elif [[ $host_type == "ibm" ]] && [[ $k8s_provider == "openshift" ]]; then
        IS_ETC_HOSTS=true
    elif [[ $k8s_provider == "iks" ]]; then
        IS_UPDATE_COREDNS=true
    fi
    if [[ $host_type == "ibm" ]]; then
        IS_CLOUD_CRED_SECRET=true
    fi
    ${SED} "s/HOST_TYPE/$host_type/" ${cr_file}.tmp
    ${SED} "s/K8S_PROVIDER/$k8s_provider/" ${cr_file}.tmp

    if [[ ! -z $NODE_SELECTOR ]]; then
        ${SED} "s%# NODE_SELECTOR%$NODE_SELECTOR%" ${cr_file}.tmp
        ${SED} "s/# node_selector/node_selector/" ${cr_file}.tmp
    fi

    if [[ ! -z $STORAGE_DISKS ]]; then
        ${SED} "s/STORAGE_DISKS/$STORAGE_DISKS/" ${cr_file}.tmp
        ${SED} "s/# storage_disks/storage_disks/" ${cr_file}.tmp
    fi

    is_options=false
    if [[ $IS_CLOUD_CRED_SECRET == true ]]; then
        ${SED} "s/CLOUD_CRED_SECRET/$CLOUD_CRED_SECRET/" ${cr_file}.tmp
        ${SED} "s/# cloud_cred_secret/cloud_cred_secret/" ${cr_file}.tmp
        is_options=true
    fi

    if [[ $IS_ETC_HOSTS == true ]]; then
        ${SED} "s/# update_etc_hosts/update_etc_hosts/" ${cr_file}.tmp
        is_options=true
    fi

    if [[ $IS_UPDATE_COREDNS == true ]]; then
        ${SED} "s/# update_coredns/update_coredns/" ${cr_file}.tmp
        is_options=true
    fi

    if [[ -n $PROXY_CERT ]]; then
        ${SED} "s%PROXY_CERTIFICATE_PATH%$PROXY_CERT%" ${cr_file}.tmp
        ${SED} "s/# proxy_certificate/proxy_certificate/" ${cr_file}.tmp
    fi

    if [[ ! -z $IMAGE_REGISTRY_PATH ]]; then
        ${SED} "s%IMAGE_REGISTRY_PATH%$IMAGE_REGISTRY_PATH%" ${cr_file}.tmp
        ${SED} "s/# image_registry_path/image_registry_path/" ${cr_file}.tmp
    fi

    if [[ ! -z $IMAGE_PULL_SECRET ]]; then
        ${SED} "s/IMAGE_PULL_SECRET/$IMAGE_PULL_SECRET/" ${cr_file}.tmp
        ${SED} "s/# image_pull_secret/image_pull_secret/" ${cr_file}.tmp
    fi

    if [[ ! -z ${VERSION} ]]; then
        ${SED} "s/${CUR_VERSION}/${VERSION}/" ${cr_file}.tmp
    fi

    if [[ ! -z ${REPO} ]]; then
        ${SED} "s/${IMAGE_REPO}/${REPO}/" ${cr_file}.tmp
    fi

    if [[ $DEVMODE -eq 1 ]]; then
        is_options=true
        ${SED} "s/# robin_devmode/robin_devmode/" ${cr_file}.tmp
    fi

    if [[ -n $VAULT_ADDR ]]; then
        is_options=true
        ${SED} "s/# kms:.*$/kms: vault/" ${cr_file}.tmp
        ${SED} "s/# vault_addr/vault_addr/" ${cr_file}.tmp
        ${SED} "s#VAULT_ADDR#$VAULT_ADDR#" ${cr_file}.tmp
        ${SED} "s/# vault_robin_keys_path/vault_robin_keys_path/" ${cr_file}.tmp
        ${SED} "s#VAULT_ROBIN_KEYS_PATH#$VAULT_ROBIN_KEYS_PATH#" ${cr_file}.tmp
        if [[ -n $VAULT_TOKEN ]]; then
            ${SED} "s/VAULT_TOKEN/$VAULT_TOKEN/" ${cr_file}.tmp
            ${SED} "s/# vault_token/vault_token/" ${cr_file}.tmp
        fi
        if [[ -n $VAULT_CACERT ]]; then
            ${SED} "s/# vault_cacert/vault_cacert/" ${cr_file}.tmp
        fi
        if [[ -n $VAULT_CLIENT_CERT ]]; then
            ${SED} "s/# vault_client_cert/vault_client_cert/" ${cr_file}.tmp
        fi
        if [[ -n $VAULT_CLIENT_KEY ]]; then
            ${SED} "s/# vault_client_key/vault_client_key/" ${cr_file}.tmp
        fi

        if [[ -n $VAULT_SKIP_VERIFY ]]; then
            ${SED} "s/VAULT_SKIP_VERIFY/$VAULT_SKIP_VERIFY/" ${cr_file}.tmp
            ${SED} "s/# vault_skip_verify/vault_skip_verify/" ${cr_file}.tmp
        fi
        if [[ -n $VAULT_NAMESPACE ]]; then
            ${SED} "s/VAULT_NAMESPACE/$VAULT_NAMESPACE/" ${cr_file}.tmp
            ${SED} "s/# vault_namespace/vault_namespace/" ${cr_file}.tmp
        fi
    fi
    if [[ $is_options == true ]]; then
        ${SED} "s/# options/options/" ${cr_file}.tmp
    fi

    cr_file=${cr_file}.tmp
    if [[ ! -z $GENERATE_YAML ]]; then
        echo -e "${GREEN}Done${NC}"
        echo "Generated yaml file is at ./$cr_file"
        exit 0
    fi
}


function install_operator() {
    operator_file="robin-operator.yaml"
    cp -f ${operator_file} ${operator_file}.tmp
    if [[ ! -z $IMAGE_REGISTRY_PATH ]]; then
        ${SED} "s%image: %image: ${IMAGE_REGISTRY_PATH}/%" ${operator_file}.tmp
    fi
    if [[ ! -z $IMAGE_PULL_SECRET ]]; then
        ${SED} "s%      containers:%      imagePullSecrets:\n      - name: $IMAGE_PULL_SECRET \n      containers:%" ${operator_file}.tmp
    fi
    if [[ ! -z ${VERSION} ]]; then
        ${SED} "s/${CUR_VERSION}/${VERSION}/" ${operator_file}.tmp
    fi
    if [[ ! -z ${REPO} ]]; then
        ${SED} "s/${IMAGE_REPO}/${REPO}/" ${operator_file}.tmp
    fi

    $KUBE_COMMAND apply -f ./${operator_file}.tmp >> $LOGFILE 2>/dev/null
    if [[ $? != 0 ]]; then
        echoerr "Failed to install robin operator"
        exit 1
    fi
    retries="100"
    i="0"

    while [ $i -lt $retries ]
    do
        $KUBE_COMMAND get crd robinclusters.manage.robin.io >> $LOGFILE
        if [[ $? == 0 ]]; then
          break
        fi
        i=$[$i+1]
        sleep 1
    done
}

function install_monitor() {
    ke_monitor_file="ke-monitor.yaml"
    cp -f ${ke_monitor_file} ${ke_monitor_file}.tmp
    if [[ ! -z $IMAGE_REGISTRY_PATH ]]; then
        ${SED} "s%image: %image: ${IMAGE_REGISTRY_PATH}/%" ${ke_monitor_file}.tmp
    fi
    if [[ ! -z $IMAGE_PULL_SECRET ]]; then
        ${SED} "s%      containers:%      imagePullSecrets:\n      - name: $IMAGE_PULL_SECRET \n      containers:%" ${ke_monitor_file}.tmp
    fi
    if [[ ! -z ${REPO} ]]; then
        ${SED} "s/${IMAGE_REPO}/${REPO}/" ${ke_monitor_file}.tmp
    fi

    $KUBE_COMMAND apply -f ./${ke_monitor_file}.tmp >> $LOGFILE 2>/dev/null
    if [[ $? != 0 ]]; then
        echoerr "Failed to install robin operator"
        exit 1
    fi
}


function create_cloud_secret() {
    $KUBE_COMMAND get secret $CLOUD_CRED_SECRET -n $NAMESPACE >> $LOGFILE 2>/dev/null
    if [[ $? == 0 ]]; then
        printf "\n"
        echowarn "secret $CLOUD_CRED_SECRET already exists. Make sure it contains correct data else installation will fail."
        return
    fi

    if [[ $host_type == "ec2" ]]; then
        $KUBE_COMMAND create secret generic $CLOUD_CRED_SECRET --from-literal=secret_key=$SECRET_KEY --from-literal=access_key=$ACCESS_KEY -n $NAMESPACE >> $LOGFILE
    elif [[ $host_type == "azure" ]]; then
        $KUBE_COMMAND create secret generic $CLOUD_CRED_SECRET --from-literal=app_id=$APP_ID --from-literal=secret_key=$SECRET_KEY --from-literal=tenant_id=$TENANT_ID  -n $NAMESPACE >> $LOGFILE
    elif [[ $host_type == "ibm" ]]; then
        $KUBE_COMMAND create secret generic $CLOUD_CRED_SECRET --from-literal=api_key=$API_KEY -n $NAMESPACE >> $LOGFILE
    fi
    if [[ $? != 0 ]]; then
        echoerr "Failed to create secret $CLOUD_CRED_SECRET"
        exit 1
    fi
}

function create_proxy_cert_secret() {
    local proxy_cert_secret="proxy-cert"
    $KUBE_COMMAND get secret $proxy_cert_secret -n $NAMESPACE >> $LOGFILE 2>/dev/null
    if [[ $? == 0 ]]; then
        printf "\n"
        echowarn "secret $proxy_cert_secret already exists. Make sure it contains correct data else installation will fail."
        return
    fi

    $KUBE_COMMAND create secret generic $proxy_cert_secret --from-file=ca.crt=$PROXY_CERT -n $NAMESPACE >> $LOGFILE
    if [[ $? != 0 ]]; then
        echoerr "Failed to create secret $proxy_cert_secret"
        exit 1
    fi
}

function create_vault_ca_secret() {
    local vault_secret="vault-ca-cert"
    $KUBE_COMMAND get secret $vault_secret -n $NAMESPACE >> $LOGFILE 2>/dev/null
    if [[ $? == 0 ]]; then
        printf "\n"
        echowarn "secret $vault_secret already exists. Make sure it contains correct data else installation will fail."
        return
    fi

    $KUBE_COMMAND create secret generic $vault_secret --from-file=ca.crt=$VAULT_CACERT -n $NAMESPACE >> $LOGFILE
    if [[ $? != 0 ]]; then
        echoerr "Failed to create secret $vault_secret"
        exit 1
    fi
}

function create_vault_client_secret() {
    vault_secret="vault-client-cert"
    $KUBE_COMMAND get secret $vault_secret -n $NAMESPACE >> $LOGFILE 2>/dev/null
    if [[ $? == 0 ]]; then
        printf "\n"
        echowarn "secret $vault_secret already exists. Make sure it contains correct data else installation will fail."
        return
    fi

    $KUBE_COMMAND create secret tls $vault_secret --cert=$VAULT_CLIENT_CERT --key=$VAULT_CLIENT_KEY -n $NAMESPACE >> $LOGFILE
    if [[ $? != 0 ]]; then
        echoerr "Failed to create secret $vault_secret"
        exit 1
    fi
}

function install_robin_cluster() {

    create_cloud_secret

    if [[ -n $VAULT_ADDR ]] &&  [[ -n $VAULT_CACERT ]]; then
        create_vault_ca_secret
    fi

    if [[ -n $VAULT_ADDR ]] &&  [[ -n $VAULT_CLIENT_CERT ]] && [[ -n $VAULT_CLIENT_KEY ]]; then
        create_vault_client_secret
    fi

    if [[ -n $PROXY_CERT ]]; then
        create_proxy_cert_secret
    fi

    $KUBE_COMMAND apply -f ./$cr_file >> $LOGFILE
    if [[ $? != 0 ]]; then
        echoerr "Failed to install robin cluster"
        exit 1
    fi

    if [[ $LB_NEEDED == true ]]; then
        $KUBE_COMMAND apply -f ./robin-lb.yaml >> $LOGFILE
        if [[ $? != 0 ]]; then
            echoerr "Failed to create load balancer service"
            exit 1
        fi
   fi

    retries="100"
    i="0"

    while [ $i -lt $retries ]
    do
        master_ip=$($KUBE_COMMAND describe robinclusters -n $NAMESPACE | grep -i [^:]Master | awk -F':' '{print $2}' | tr -d " \n")
        if [[ $? == 0 ]] && [[ $master_ip != ""  ]]; then
          break
        fi
        i=$[$i+1]
        sleep 6
    done
    if [ $i -eq $retries ]; then
        echoerr "Failed to install robin cluster. Failed to select robin master. Please collect robin-operator pod logs and try reinstalling."
        exit 1
    fi
}

function get_client_os() {
    uname_s=$(uname -s | tr -d " \n")
    os=""
    if [[ $uname_s == "Darwin" ]]; then
        os="mac"
        SED="sed -i''"
    elif [[ $uname_s == "Linux" ]]; then
        os="linux"
        SED="sed -i"
    else
        os=""
    fi
}

function setup_robin_client() {
    if [[ $os != "linux" ]] && [[ $os != "mac" ]]; then
        echoerr "Robin is installed but robin client is only supported on linux or mac"
        exit 1
    fi

    get_master_ip
    ii=0
    while true; do
        out=$(curl -k -s https://$master_ip:29442/api/v3/robin_server)
        if [[ $? == 0 ]]; then
            echo "Robin server is up" >> $LOGFILE
            break
        fi
        echo "Waiting for robin server to come up" >> $LOGFILE
        ii=$((ii+ 1))
        sleep 5
        # 900 seconds
        if [[ $ii -gt 180 ]]; then
            echowarn "Timed out waiting for robin server to come up"
            break
        fi
    done

    # For some reason aws load balancer even if working as previous curl, the next curl still fails so adding sleep
    ii=0
    while true; do
        $(curl -k -s "https://$master_ip:29442/api/v5/robin_server/download?file=robincli&os=$os" -o robin ) >> $LOGFILE 2>/dev/null
        if [[ $? == 0 ]]; then
            echo "Robin client is downloaded" >> $LOGFILE
            break
        fi
        echo "Waiting for robin client download" >> $LOGFILE
        ii=$((ii+ 1))
        sleep 5
        # 900 seconds
        if [[ $ii -gt 180 ]]; then
            echowarn "Failed to install robin client. Make sure port 29442 is open to connect"
            return
        fi
    done

    chmod +x robin
    ./robin client add-context $master_ip --set-current >> $LOGFILE 2>/dev/null

    retries="100"
    i="0"

    while [ $i -lt $retries ]
    do
        ./robin login admin --password Robin123 >> $LOGFILE 2>/dev/null
        if [[ $? == 0 ]]; then
            break
        fi
        echo "Failed to login to robin cluster, Retries $i/$retries" >> $LOGFILE
        i=$[$i+1]
        sleep 5
    done
    if [ $i -eq $retries ]; then
        master_pod=`kubectl get pod -n robinio --selector=robin.io/robinrole=master -o jsonpath='{.items[0].metadata.name}' 2> /dev/null`
        if [[ $? == 0 ]]; then
            echoerr "Failed to login to robin cluster. Check /var/log/robin/robin-bootstrap.log in pod $master_pod in $NAMESPACE. In IKS env, there are some issues with port availability so please try reinstalling robin." >> $LOGFILE
            exit 1
        else
            echoerr "Failed to login to robin cluster." >> $LOGFILE
            exit 1
        fi
    fi
}

function setup_default_storage_class(){
    if [[ $k8s_provider == 'rke' ]] || [[ $k8s_provider == 'upstream' ]]; then
        kubectl patch storageclass robin -p '{"metadata": {"annotations":{"storageclass.kubernetes.io/is-default-class":"true"}}}' >> $LOGFILE
    fi
}

function get_master_ip() {
    if [[ $LB_NEEDED == false ]]; then
        return
    fi
    while true; do
        lb_hostname=$($KUBE_COMMAND get service -n $NAMESPACE robin-admin -o custom-columns=LBHostName:.status.loadBalancer.ingress[*].hostname --no-headers)
        if [[ $? != 0 ]] || [[ -z $lb_hostname ]] || [[ $lb_hostname == ""  ]] || [ $lb_hostname == "<none>" ]; then
            lb_hostname=$($KUBE_COMMAND get service -n $NAMESPACE robin-admin -o custom-columns=LBHostName:.status.loadBalancer.ingress[*].ip --no-headers)
        fi
        if [[ $? == 0 ]] && [[ ! -z $lb_hostname ]] && [[ $lb_hostname != ""  ]] && [ $lb_hostname != "<none>" ]; then
            echo "Load balancer hostname is $lb_hostname" >> $LOGFILE
            break
        fi
        echo "Waiting for load balancer getting hostname" >> $LOGFILE
        sleep 5
    done
    master_ip=$lb_hostname
}

function is_cloud() {
    if [[ $host_type == 'gcp' ]] || [[ $host_type == 'ec2' ]]; then
        cloud=1
    else
        cloud=0
    fi
}

function handle_license(){
    ii=0
    while true; do
        license=$(./robin license id | grep 'Id'| awk -F' ' '{print $3}')
        if [[ $? == 0 ]]; then
            echo "Got the license id" >> $LOGFILE
            break
        fi
        echo "Waiting for license id" >> $LOGFILE
        ii=$((ii+ 1))
        sleep 5
        # 900 seconds
        if [[ $ii -gt 180 ]]; then
            echowarn "Timed out getting license id"
            break
        fi
    done


    cat << EOF
       $ robin license activate <USERID>

       Note: You can get your User ID after registering on https://get.robin.io. Above command will only work if the host on which the
             ROBIN client is running on has an internet connection. If this is not the case please retrieve the license key by using the
             below link and apply it using the command 'robin license apply <key>'.

             https://get.robin.io/activate?clusterid=$license

      For logging into robin cluster,
      Default username: admin
      Default password: Robin123
EOF
}

function parse_arguments(){
    for ARGUMENT in "$@"
    do

        KEY=$(echo $ARGUMENT | cut -f1 -d=)
        VALUE=$(echo $ARGUMENT | cut -f2 -d=)

        case "$KEY" in
                -a | --access-key)              ACCESS_KEY=${VALUE} ;;
                -s | --secret-key)              SECRET_KEY=${VALUE} ;;
                -p | --app-id)                  APP_ID=${VALUE} ;;
                -t | --tenant-id)               TENANT_ID=${VALUE} ;;
                -i | --api-key)                 API_KEY=${VALUE} ;;
                -c | --cluster-name)            CLUSTER_NAME=${VALUE} ;;
                -z | --zone-name)               ZONE_NAME=${VALUE} ;;
                -g | --generate-yaml)           GENERATE_YAML=1 ;;
                -f | --cr)                      CR_FILE=${VALUE} ;;
                -n | --node-selector)           NODE_SELECTOR=${VALUE} ;;
                -k | --skip-lb)                 SKIP_LB=1 ;;
                -u | --uninstall)               UNINSTALL=1 ;;
                -y | --yes)                     YES=1;;
                -r | --image-registry-path)     IMAGE_REGISTRY_PATH=${VALUE} ;;
                -l | --image-pull-secret)       IMAGE_PULL_SECRET=${VALUE} ;;
                -v | --version)                 VERSION=${VALUE} ;;
                -d | --debug)                   set -x;;
                -h | --help)                    help;;
                --devmode)                      DEVMODE=1 ;;
                --vault-addr)                   VAULT_ADDR=${VALUE};;
                --vault-keys-path)              VAULT_ROBIN_KEYS_PATH=${VALUE};;
                --vault-skip-verify)            VAULT_SKIP_VERIFY=true;;
                --vault-ca-cert)                VAULT_CACERT=${VALUE};;
                --vault-client-cert)            VAULT_CLIENT_CERT=${VALUE};;
                --vault-client-key)             VAULT_CLIENT_KEY=${VALUE};;
                --vault-token)                  VAULT_TOKEN=${VALUE};;
                --vault-namespace)              VAULT_NAMESPACE=${VALUE};;
                --proxy-cert)                   PROXY_CERT=${VALUE};;
                --repo)                         REPO=${VALUE};;
                *)                              echoerr "unkown option $KEY"; exit 1;;
        esac
    done
}

function help(){
    echo -e "Usage: $0 [-a|--access-key=AWS-ACCESS-KEY -s|--secret-key=SECRET-KEY]"
    echo -e "          [-p|--app-id=AZURE-APP-ID -t|--tenant-id=AZURE-TENANT-ID -i|--api-key=API-KEY]"
    echo -e "          [-c|--cluster-name=GKE-CLUSTER-NAME -z|--zone-name=GKE-CLUSTER-ZONE]"
    echo -e "          [-g|--generate-yaml -f|--cr=CR-FILE -n|--node-selector=NODE-SELECTOR]"
    echo -e "          [-r|--image-registry-path -l|--image-pull-secret -k|--skip-lb]"
    echo -e "          [-u|--uninstall] [-v|--version] [-y|--yes] [-d|--debug]"
    echo -e "          [--vault-addr=VAULT_ADDR --vault-keys-path=VAULT_KEYS_PATH] "
    echo -e "          [--vault-token=VAULT_TOKEN] [--vault-ca-cert=VAULT_CACERT --vault-client-cert=VAULT_CLIENT_CERT --vault-client-key=VAULT_CLIENT_KEY]"
    echo -e "          [--vault-namespace=VAULT_NAMESPACE] [--vault-skip-verify=true|false]"
    echo -e "          [--proxy-cert=PROXY_CERT] [--repo=REPO] [-h|--help]"
    exit 0
}

# Code borrowed from https://antofthy.gitlab.io/info/crypto/passwd_input.txt
function read_user_priv_data(){
    local PWORD=
    while true; do
      IFS= read -r -N1 -s char
      # Note a NULL will return a empty string
      # Convert users key press to hexadecimal character code
      code=$(printf '%02x' "'$char") # EOL (empty char) -> 00
      case "$code" in
      ''|0a|0d) break ;;   # Exit EOF, Linefeed or Return
      08|7f)  # backspace or delete
          if [ -n "$PWORD" ]; then
            PWORD="$( echo "$PWORD" | sed 's/.$//' )"
            echo -n $'\b \b' 1>&2
          fi
          ;;
      15) # ^U or kill line
          echo -n "$PWORD" | sed 's/./\cH \cH/g' >&2
          PWORD=''
          ;;
      [01]?) ;;                        # Ignore ALL other control characters
      *)  PWORD="$PWORD$char"
          echo -n '*' 1>&2
          ;;
      esac
    done
    echo $PWORD
}

function check_args(){
    if [[ $host_type == 'ec2' ]]; then
        if [[ ! -z $ACCESS_KEY ]]; then
            input_access_key=0
        fi
        access_key_valid=1
        while [[ $access_key_valid  == 1 ]]; do
            if [[ $input_access_key != 0 ]]; then
                echo -n "Enter AWS access key: "
                ACCESS_KEY=$(read_user_priv_data)
                echo
            fi
            ACCESS_KEY="$(echo -e "${ACCESS_KEY}" | tr -d '[:space:]')"
            validate_access_key
            if [[ $access_key_valid  == 1 ]]; then
                echoerr "Access key $ACCESS_KEY invalid"
                if [[ $input_access_key == 0 ]]; then
                    exit 1
                fi
            fi
        done
        if [[ ! -z $SECRET_KEY ]]; then
            input_secret_key=0
        fi
        secret_key_valid=1
        while [[ $secret_key_valid == 1 ]]; do
            if [[ $input_secret_key  != 0 ]]; then
                echo -n "Enter AWS secret key: "
                SECRET_KEY=$(read_user_priv_data)
                echo
            fi
            SECRET_KEY="$(echo -e "${SECRET_KEY}" | tr -d '[:space:]')"
            validate_secret_key
            if [[ $secret_key_valid == 1 ]]; then
                echoerr "Secret key $SECRET_KEY invalid"
                if [[ $input_secret_key == 0 ]]; then
                    exit 1
                fi
            fi
        done
    fi
    if [[ $host_type == 'azure' ]]; then
        if [[ -z $APP_ID ]] ||  [[ -z $TENANT_ID ]] || [[ -z $SECRET_KEY ]]; then
            echoerr "Please provide app-id, tenant-id and secret-key for azure"
            exit 1
        fi
    fi
    if [[ $host_type == 'gcp' ]] && [[ $k8s_provider == 'gke' ]]; then
        which gcloud > /dev/null
        if [[ $? != 0 ]]; then
            echowarn "gcloud not available so cannot verify cluster permissions"
            return
        fi
        if [[ -z $CLUSTER_NAME ]]; then
            echo -n "Enter GKE cluster name: "
            read CLUSTER_NAME
        fi
        if [[ -z $ZONE_NAME ]]; then
            echo -n "Enter GKE zone name: "
            read ZONE_NAME
        fi
    fi

    if [[ $host_type == 'ibm' ]]; then
        ibm_api_key=1
        while [[ $ibm_api_key == 1 ]]; do
            if [[ -z $API_KEY ]]; then
                echo -n "Enter IBM API key: "
                API_KEY=$(read_user_priv_data)
                echo
                API_KEY="$(echo -e "${API_KEY}" | tr -d '[:space:]')"
            fi
            validate_ibm_api_key
            if [[ $ibm_api_key == 1 ]]; then
                echoerr "IBM API key $API_KEY invalid"
                API_KEY=""
            fi
        done
    fi

    if [[ ! -z $IMAGE_PULL_SECRET ]]; then
        validate_secret
    fi
    IMAGE_REGISTRY_PATH=`echo "$IMAGE_REGISTRY_PATH" | sed 's/\/*$//g'`

    if [[ $VAULT_ADDR != '' ]]; then
        if [[ -z $VAULT_ROBIN_KEYS_PATH ]]; then
            echoerr "Please provide --vault-keys-path for vault"
            exit 1
        fi
        if [[ -z $VAULT_TOKEN ]]; then
            if [[ -z $VAULT_CACERT ]] ||  [[ -z $VAULT_CLIENT_CERT ]] || [[ -z $VAULT_CLIENT_KEY ]]; then
                echoerr "Please provide --vault-token or (--vault-ca-cert and --vault-client-key and --vault-client-cert) for vault"
                exit 1
            fi
        fi
        if [[ -n $VAULT_CACERT ]] && [[ ! -f $VAULT_CACERT ]]; then
            echoerr "Please provide valid file for --vault-ca-cert"
            exit 1
        fi
        if [[ -n $VAULT_CLIENT_CERT ]] && [[ ! -f $VAULT_CLIENT_CERT ]]; then
            echoerr "Please provide valid file for --vault-client-cert"
            exit 1
        fi
        if [[ -n $VAULT_CLIENT_KEY ]] && [[ ! -f $VAULT_CLIENT_KEY ]]; then
            echoerr "Please provide valid file for --vault-client-key"
            exit 1
        fi
    fi

    if [[ -n $PROXY_CERT ]] && [[ ! -f $PROXY_CERT ]]; then
        echoerr "Please provide valid file for --proxy-cert"
        exit 1
    fi
}

function validate_access_key {
    ACCESS_KEY="$(echo -e "${ACCESS_KEY}" | tr -d '[:space:]')"
    if ! [[ $ACCESS_KEY =~ ^[A-Z0-9]{20}\s? ]]; then
        access_key_valid=1
        return
    fi
    access_key_valid=0
}

function validate_secret_key() {
    SECRET_KEY="$(echo -e "${SECRET_KEY}" | tr -d '[:space:]')"
    if ! [[ $SECRET_KEY =~ ^[A-Za-z0-9/+=]{40}\s? ]]; then
        secret_key_valid=1
        return
    fi
    secret_key_valid=0
}

function validate_ibm_api_key {
    API_KEY="$(echo -e "${API_KEY}" | tr -d '[:space:]')"
    if ! [[ $API_KEY =~ ^[A-Za-z0-9_-]{44}\s? ]]; then
        ibm_api_key=1
        return
    fi
    ibm_api_key=0
}

function validate_secret() {
    $KUBE_COMMAND get secret -n $NAMESPACE $IMAGE_PULL_SECRET >> $LOGFILE 2>/dev/null
    if [[ $? != 0 ]]; then
        echoerr "secret $IMAGE_PULL_SECRET doesn not exist in $NAMESPACE"
        exit 1
    fi
}

function get_kube_command {
    # Check kubectl
    KUBE_COMMAND="kubectl"
    which kubectl > /dev/null 2>&1
    if [[ $? != 0 ]]; then
        which oc > /dev/null 2>&1
        if [[ $? != 0 ]]; then
            echoerr "kubectl/oc is not found in the path"
            exit 1
         fi
         KUBE_COMMAND="oc"
    fi
}

function confirm_install_robin {
    echowarn "This operation will delete the ROBIN cluster and can not be undone at later point."
    while true; do
        echo -ne "Type ${RED}'delete'${NC} to confirm that you want to uninstall: "
        read var
        if [[ ! -z $var ]] && ([[ $var == 'delete' ]] || [[ $var == 'DELETE' ]]) ; then
            return
        fi
        if [[ ! -z $var ]] && ([[ $var == 'no' ]] || [[ $var == 'NO' ]]); then
            exit 1
        fi
    done
}

function uninstall_robin_cluster {
    get_kube_command
    $KUBE_COMMAND delete -f robin-operator.yaml >> $LOGFILE 2>/dev/null
    while true; do
        $KUBE_COMMAND get ns $NAMESPACE >> $LOGFILE 2>/dev/null
        if [[ $? != 0 ]]; then
            break
        fi
        sleep 5
    done
    $KUBE_COMMAND delete clusterrolebinding -l robin.io/domain=ROBIN  >> $LOGFILE 2>/dev/null
    $KUBE_COMMAND delete rolebinding -l robin.io/domain=ROBIN -A >> $LOGFILE 2>/dev/null
    $KUBE_COMMAND get ns -l robin.io/domain=ROBIN | grep NAME >> $LOGFILE 2>/dev/null

    if [[ $? == 0 ]]; then
        echo -e "${GREEN}Done${NC}"
        namespaces=$($KUBE_COMMAND get ns -l robin.io/domain=ROBIN | grep -v NAME| awk -F' ' '{print $1}')
        namespaces=$(echo "$namespaces"|tr '\n' ' ')
        echo "Some Robin managed namespaces ($namespaces) are not deleted, please run following command to delete those after "
        echo -e "making sure there are no required kubernetes objects present in these namespaces"
        echo -e "\"$KUBE_COMMAND delete ns -l robin.io/domain=ROBIN\""
    else
        echo -e "${GREEN}Done${NC}"
    fi
}

function confirm_ports {
    if [[ ! -z $YES ]] && [[ $YES == 1 ]]; then
        return
    fi
    is_cloud
    if [[ $cloud == 1 ]]; then
        echo -e "\nConfirm that ports 29442-29470 are open between kubernetes nodes"
    fi
    echo -e "Make sure the cluster meets prerequisites mentioned at https://docs.robin.io/storage/latest/install.html#prerequisites"
    while true; do
        echo -n "Type yes to confirm that cluster meets the prerequisites: "
        read var
        if [[ ! -z $var ]] && ([[ $var == 'yes' ]] || [[ $var == 'YES' ]]) ; then
            return
        fi
        if [[ ! -z $var ]] && ([[ $var == 'no' ]] || [[ $var == 'NO' ]]); then
            exit 1
        fi
    done
}

function finish(){
    exit_code=$?
    set +x
    exit ${exit_code}
}


GREEN='\033[0;32m'
YELLOW='\033[1;35m'
RED='\033[0;31m'
NC='\033[0m' # No Color
trap finish EXIT
parse_arguments "$@"
if [[ ! -z $UNINSTALL ]] && [[ $UNINSTALL == 1 ]]; then
    confirm_install_robin
    echo -n "Uninstalling Robin cluster......"
    uninstall_robin_cluster
    exit 0
fi
echo -n "Validating Kubernetes cluster......"
validate_k8s_cluster
echo -e "${GREEN}Done${NC}"
confirm_ports
check_args
echo -n "Validating kubernetes cluster permissions......"
validate_perms
echo -e "${GREEN}Done${NC}"
echo -n "Validating robin cluster yaml......"
validate_cr_yaml
echo -e "${GREEN}Done${NC}"
echo -n "Installing Robin operator..........."
install_operator
echo -e "${GREEN}Done${NC}"
echo -n "Installing Robin cluster............"
install_robin_cluster
echo -e "${GREEN}Done${NC}"
echo -n "Installing Robin monitor............"
install_monitor
echo -e "${GREEN}Done${NC}"
echo -n "Setting up robin client............"
setup_robin_client
setup_default_storage_class
echo -e "${GREEN}Done${NC}\n"
echo -n "Activate robin license............"
echo -e "${YELLOW}Required${NC}\n"
handle_license
